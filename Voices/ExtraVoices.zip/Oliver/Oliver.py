VOICE_PROFILE = {
    "name": "Oliver",
    "gender": "male",
    "accent": "british",
    "base_pitch": 110.0,
    "formant_scale": 1.30,
    "duration_scale": 1.20,
    "noise_level": 0.28,
    "brightness": -0.40,
    "description": "Oliver: High male, slow, dark, clean."
}
