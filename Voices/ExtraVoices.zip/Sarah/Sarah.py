VOICE_PROFILE = {
    "name": "Sarah",
    "gender": "female",
    "accent": "american",
    "base_pitch": 155.0,
    "formant_scale": 0.85,
    "duration_scale": 1.25,
    "noise_level": 0.40,
    "brightness": 0.50,
    "description": "Sarah: Highest, brightest, slowest, most breathy female."
}
