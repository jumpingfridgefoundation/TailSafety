VOICE_PROFILE = {
    "name": "Sofia",
    "gender": "female",
    "accent": "spanish",
    "base_pitch": 142.0,
    "formant_scale": 0.86,
    "duration_scale": 1.15,
    "noise_level": 0.43,
    "brightness": 0.48,
    "description": "Sofia: High, very bright, slow, most breathy."
}
