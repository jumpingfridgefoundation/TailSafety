VOICE_PROFILE = {
    "name": "Priya",
    "gender": "female",
    "accent": "indian",
    "base_pitch": 145.0,
    "formant_scale": 0.89,
    "duration_scale": 0.85,
    "noise_level": 0.41,
    "brightness": 0.35,
    "description": "Priya: High, bright, fast, very breathy."
}
