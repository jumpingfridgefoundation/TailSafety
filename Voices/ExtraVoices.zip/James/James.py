VOICE_PROFILE = {
    "name": "James",
    "gender": "male",
    "accent": "american",
    "base_pitch": 75.0,
    "formant_scale": 1.45,
    "duration_scale": 0.80,
    "noise_level": 0.25,
    "brightness": -0.50,
    "description": "James: Deepest, darkest, fastest, cleanest male."
}
