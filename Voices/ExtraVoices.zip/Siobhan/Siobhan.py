VOICE_PROFILE = {
    "name": "Siobhan",
    "gender": "female",
    "accent": "irish",
    "base_pitch": 140.0,
    "formant_scale": 0.90,
    "duration_scale": 1.18,
    "noise_level": 0.37,
    "brightness": 0.30,
    "description": "Siobhan: High, bright, slow, moderate breath."
}
