VOICE_PROFILE = {
    "name": "Liam",
    "gender": "male",
    "accent": "irish",
    "base_pitch": 85.0,
    "formant_scale": 1.40,
    "duration_scale": 1.30,
    "noise_level": 0.35,
    "brightness": -0.45,
    "description": "Liam: Deep, slow, dark, moderate noise."
}
