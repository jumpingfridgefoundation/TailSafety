VOICE_PROFILE = {
    "name": "Emma",
    "gender": "female",
    "accent": "british",
    "base_pitch": 150.0,
    "formant_scale": 0.87,
    "duration_scale": 1.10,
    "noise_level": 0.39,
    "brightness": 0.45,
    "description": "Emma: Very high, very bright, slightly slow, breathy."
}
