VOICE_PROFILE = {
    "name": "Raj",
    "gender": "male",
    "accent": "indian",
    "base_pitch": 80.0,
    "formant_scale": 1.42,
    "duration_scale": 0.90,
    "noise_level": 0.27,
    "brightness": -0.48,
    "description": "Raj: Deep, fast, very dark, very clean."
}
